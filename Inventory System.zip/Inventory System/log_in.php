<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign in</title>
    <link rel="icon" type="image/png" href="newLogo.png">
</head>
<body>
    <div class="log_in_container">
        <form action="log_in.php" method="post" id="log">
            <h2 id="log_in_head">Log in</h2>
            <?php
            if ($_SERVER["REQUEST_METHOD"] == 'POST' && isset($_SESSION["invalid"])) {
                echo "<h4 style='color: white; text-align: center;'>" . $_SESSION["invalid"] . "</h4>";
                unset($_SESSION["invalid"]);
            }
            ?>
            <label>Email or Username</label><br>
            <input type="text" name="username" class="textbox" required><br><br>
            <label>Password</label><br>
            <input type="password" name="password" class="textbox" required><br><br>
            <input type="submit" class="log_in_page_buttons" id="log_in" name="log_in" value="Log in"><br><br>
            <p>Don't have an account? <a href="sign_up.php">Register</a> or</p>
            <p id="fr">Forgot your password? <a href="forgot_password.php">Reset</a></p>
        </form>
        <?php
        try{
include("dataBase.php");
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["log_in"])
&& !empty($_POST["username"]) && !empty($_POST["password"])) {
    $username = filter_input(INPUT_POST, "username", FILTER_SANITIZE_EMAIL);
    $password = filter_input(INPUT_POST, "password", FILTER_SANITIZE_SPECIAL_CHARS);

    $sql = "SELECT * FROM users_info WHERE email_address = ?";
    $stmt = mysqli_prepare($conn, $sql);
     $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if (password_verify($password, $row['password'])) {
                $_SESSION["username"] = $username;
                header("Location: dashboard.php");
                exit;
            } else {
                $_SESSION["invalid"] = "Invalid password!";
            }
        } else {
            $_SESSION["invalid"] = "No user found with that email!";
        }
        $stmt->close();
    }
        } catch (Exception $e) {
            echo "<h4 style='color: red;'>Error: " . $e->getMessage() . "</h4>";
        }
?>
    </div>
    <div class="logo">
    <img id="logo" src="newLogo.png" alt="logo" width="400" height="400"><br><br>
    <h3>Streamline Your Stock, Maximize Your Success!</h3>
</div>
</body>
</html>
<style>
    * {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #b3d5e4;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

.log_in_container {
    background-color: #98c4e9;
    padding: 40px;
    border-radius: 16px;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 400px;
}

#log_in_head {
    text-align: center;
    color: #1e3a5f;
    margin-bottom: 20px;
}

#log {
    display: flex;
    flex-direction: column;
}

#log label {
    color: #3a3a3a;
    font-size: 14px;
    margin-bottom: 6px;
}

.textbox {
    padding: 12px 14px;
    border: 1px solid #cbd5e0;
    border-radius: 8px;
    margin-bottom: 20px;
    font-size: 15px;
    transition: border-color 0.3s ease;
}

.textbox:focus {
    border-color: #60a5fa;
    outline: none;
    box-shadow: 0 0 0 3px rgba(96, 165, 250, 0.4);
}

.log_in_page_buttons {
    background-color: #3b82f6;
    color: white;
    padding: 12px;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.log_in_page_buttons:hover {
    background-color: #2563eb;
}

#log p {
    text-align: center;
    margin-top: 10px;
    font-size: 14px;
    color: #555;
}

#log a {
    color: #3b82f6;
    text-decoration: none;
}

#log a:hover {
    text-decoration: underline;
}

.logo {
    display: none;
}

@media (max-width: 480px) {
    .log_in_container {
        padding: 30px 20px;
        margin: 0 10px;
    }
}

</style>