<?php
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
    if (!isset($_SESSION["username"])) {
        header("Location: main.php"); 
        exit();
    }
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['logout'])) {
    unset($_SESSION['username']);
    session_unset();
    session_destroy();
    header("Location: main.php");
    exit();

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dash Board</title>
    <link rel="icon" type="image/png" href="newLogo.png">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v3.0.6/css/line.css">
</head>
<body>
    <div class="head">
    <?php
            $ch = curl_init("http://127.0.0.1:8000/api/current-time/");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            
            $response = curl_exec($ch);
            
            if (curl_errno($ch)) {
                echo 'cURL error: ' . curl_error($ch);
                curl_close($ch);
                exit;
            }
            
            curl_close($ch);
            
            $data = json_decode($response);
            
            if (json_last_error() !== JSON_ERROR_NONE) {
                echo "Error Occured";
                exit; 
            }
            
            if (isset($data->current_time) && isset($data->timezone)) {
                $_SESSION["Date/Time"] = htmlspecialchars($data->current_time);
                $_SESSION["City"] =  htmlspecialchars($data->timezone);
                echo "Date/Time:", htmlspecialchars($data->current_time), " ", " ";
                echo "City:", htmlspecialchars($data->timezone);
            } else {
             echo "Request did not Respond.";
            }
        ?>
    </div>   
    <div class="side">
                 <form action="header.php" method="post">
                 <ul>
                    <a href="dashboard.php"><li>Home</li></a><br><br><br>
                    <a href="history.php"><li>History</li></a><br><br><br>
                    <a href="settings.php" name=""><li>Settings</li></a><br><br><br>
                   <li><button name="logout" id="logout">Logout</button></li>
                 </ul>
                 </form>
    </div>  
</body>
</html>
<style>
body {
    justify-content: center;
    text-align: center;
    color: white;
    margin: 0;
}

.side {
    float: left;
    background: linear-gradient(to bottom, rgb(48, 93, 243), rgb(17, 204, 228));
    position: fixed;
    height: 150vh;
    width: 80px;
    text-align: center;
    transform: translateY(-100px);
}

.side li {
    display: block;
    transform: translateY(100px);
}

.side ul a {
    text-decoration: none;
}

.side ul li {
    margin-left: -40px;
    font-weight: bold;
    color: white;
}

ul li:hover {
    background-color: white;
    color: black;
    padding: 10px;
    transition: all 0.4s ease-in-out;
}

#logout {
    font-size: 15px;
    background-color: transparent;
    padding: 5px;
    border: none;
    font-weight: bold;
    color: white;
}

#logout:hover {
    color: black;
    font-weight: bold;
}

.head {
    background-color: black;
    box-shadow: 0 4px 20px rgba(235, 55, 55, 0.5);
    margin-bottom: 20px;
}

i {
    font-size: 30px;
}

i:hover {
    background-color: aqua;
    border-radius: 50px;
    color: red;
}

.nav {
    margin: 0 110px;
    display: inline-block;
    overflow: hidden;
}

.nav_container {
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    padding-top: 20px;
    padding-bottom: 20px;
}

@media (max-width: 600px) {
    .nav {
        margin: 0 10px;
    }
}

</style>