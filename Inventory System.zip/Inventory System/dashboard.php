<?php
include("header.php");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
    if (!isset($_SESSION["username"])) {
        header("Location: main.php"); 
        exit();
    }

    if (!isset($_SESSION['product_name'])) {
        $_SESSION['product_name'] = [];
    }
    if (!isset($_SESSION['stock'])) {
        $_SESSION['stock'] = [];
    }
    if (!isset($_SESSION['price'])) {
        $_SESSION['price'] = [];
    }
    if (!isset($_SESSION['sold'])) {
        $_SESSION['sold'] = [];
    }
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST["reg"])) {
        if($_POST["sold"] >= $_POST["stock"]) {
            echo "Sold cannot be greater than to stock";
        } else {
            $user_input = trim($_POST['product_name']);
            $price = trim($_POST['price']);
            $stock = trim($_POST['stock']);
            $sold = trim($_POST['sold']);
            header("location: dashboard.php");
            if($sold >  $stock) {
                echo "Sold cannot be greater than stock!";
        }
    }
    }
        if (!empty($user_input) && !empty($price) && !empty($stock)
            && !empty($sold)) {
            $_SESSION['product_name'][] = $user_input;
            $_SESSION['price'][] = $price;
            $_SESSION['stock'][] = $stock;
            $_SESSION['sold'][] =  $sold;
            header("location: dashboard.php");
            }

        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_input'])) {
    $index_to_delete = intval($_POST['index']);
    if (isset($_SESSION['product_name'][$index_to_delete])) {
        unset($_SESSION['product_name'][$index_to_delete]);
        unset($_SESSION['price'][$index_to_delete]);
        unset($_SESSION['stock'][$index_to_delete]);
        unset($_SESSION['sold'][$index_to_delete]);
        $_SESSION['product_name'] = array_values($_SESSION['product_name']);
        $_SESSION['price'] = array_values($_SESSION['price']);
        $_SESSION['stock'] = array_values($_SESSION['stock']);
        $_SESSION['sold'] = array_values($_SESSION['sold']);
        header("location: dashboard.php");
    }
}  
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dash Board</title>
    <link rel="icon" type="image/png" href="newLogo.png">
</head>
<body>
    <main class="right-con">
        <aside class="ass">
        <h6>Please Fill Out The Following:</h6>
        <form action="dashboard.php" method="post">
        <input type="text" class="input" placeholder="Enter Product Name...."
        name="product_name"><br><br>
        <input type="number" class="input" placeholder="Stock...." 
        name="stock"><br><br>
        <input type="number" step ="0.01" class="input" placeholder="Product Price...." name="price"><br><br>
        <input type="number" class="input" placeholder="Sold Out...." name="sold"><br><br>
        <button id="button" type="submit" class="input" name="reg">Register</button>
        </aside>
        <div class="tabs">
            <table>
                <tr align="center">
                    <th width="150" >Product Name</th><t></t>
                    <th width="150" >Stock</th>
                    <th width="150" >Product Price</th>
                    <th width="150" >Sold Out</th>
                    <th width="150" ></th>
                </tr>
                <tr align="center">
                    <td class="data" name="table-data"><?php foreach ($_SESSION['product_name'] as $input) {
            echo "<h6>" . htmlspecialchars($input) . "</h6>";
        }
        ?></td>
                    <td  class="data" name="table-data"><?php foreach ($_SESSION['stock'] as $input) {
            echo "<h6>" . htmlspecialchars($input) . "</h6>";
            }
            ?></td>
                    <td  class="data" name="table-data"> <?php foreach ($_SESSION['price'] as $input) {
            echo "<h6>₱" . htmlspecialchars($input) . "</h6>";
        }
        ?></td>
                    <td  class="data"><?php 
                     foreach ($_SESSION['sold'] as $input) {
            echo "<h6>" . htmlspecialchars($input) . "</h6>";
        }
        ?></td>
            <td><?php
        foreach ($_SESSION['product_name'] as $index => $input) {
                echo "<h6> <form method='post' action='dashboard.php' style='display:inline;'>
                    <input type='hidden' name='index' value='$index'>
                    <button type='submit' id='del_but' name='delete_input'>Delete</button>
                </form></h6>";    
        }
        ?></td>
                </tr>
            </table>
        </div>
        </form>
       <a href="calcResult.php"><button id="calcButton">Calculate</button>
    </main>
</body>
</html>
<style>
    
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}


body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #1F3A3D; 
    color: #fff;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}


.right-con {
    display: flex;
    justify-content: space-between;
    width: 90%;
    max-width: 1200px;
    margin-top: 20px;
    padding: 30px;
    border-radius: 12px;
    background-color: #ffffff;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
}


.ass {
    width: 48%;
    background-color: #f8f9fa; 
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
}

.ass h6 {
    font-size: 18px;
    color: #2C3E50; 
    margin-bottom: 15px;
}


.input {
    font-size: 18px;
    padding: 12px;
    border-radius: 8px;
    width: 100%;
    margin-bottom: 15px;
    border: 1px solid #BDC3C7; 
    background-color: #ecf0f1; 
    transition: all 0.3s ease;
}

.input:focus {
    border-color: #3498db; 
    outline: none;
    box-shadow: 0 0 5px rgba(52, 152, 219, 0.3);
}


#button {
    background-color: #E74C3C; 
    color: white;
    border: none;
    font-weight: bold;
    padding: 14px;
    font-size: 18px;
    width: 100%;
    border-radius: 50px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

#button:hover {
    background-color: #e73131; 
    color: white;
}


.tabs {
    width: 48%;
    overflow-x: auto;
    background-color: #ecf0f1;
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
    padding: 20px;
    max-height: 400px;
    text-align: center;
}


th {
    font-size: 18px;
    color: #2C3E50;
    padding: 10px;
    background-color: #3498db; 
    color: white;
}


td {
    font-size: 16px;
    padding: 12px;
    color: #2C3E50;
    border-bottom: 1px solid #ddd;
}


.data h6 {
    font-size: 16px;
    color: #34495e; 
}


#del_but {
    background-color: #e74c3c; 
    color: white;
    border-radius: 5px;
    font-weight: bold;
    border: none;
    padding: 8px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

#del_but:hover {
    background-color: #c0392b; 
}


#calcButton {
    background-color: #3498db; 
    color: white;
    font-weight: bold;
    padding: 14px 20px;
    width: 100%;
    border-radius: 50px;
    font-size: 18px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

#calcButton:hover {
    background-color: #2980b9;
}


@media (max-width: 768px) {
    .right-con {
        flex-direction: column;
        align-items: center;
    }

    .ass, .tabs {
        width: 100%;
        margin-bottom: 20px;
    }

    #button, #calcButton {
        width: 100%;
    }
}

</style>
