<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Main Interface</title>
    <link rel="icon" type="image/png" href="newLogo.png">
</head>
<body class="main">
        <div class="right">
          <?php
include("nnav.php");
?>?
        </div>
        <div class="tit">
           <h1 align="center" style="margin-left:20px;">Welcome to Daily Sales Inventory</h1>
        </div>
        <img src="newLogo.png" alt="logo" width="300" height="300" style="display: block; margin: 0 auto;"><br><br>
        <div class="yt">
          <img src="yt.png" alt="png" width="500" height="500" style="display: block; margin: 0 auto;">
        </div>
</body>
</html>
<style>
  body{
  margin: 0%;
  background-color: rgb(0, 128, 107);
  overflow: hidden;
  }
  body img{
    text-align: center;
    transform: translateY(-165%);
    position: absolute;
  }
  .yt{
    float: right;
    transform: translateY(300px);
    margin-left: 800px;
    position: absolute;
  }
  .yt img{
    border-top-left-radius: 250px;
  }
  .right{
    color: white;
    transform: translateY(-50%);
    background-color: black;
    height: 100vh;
    display: inline-block;
    width: 100%;
    border-bottom-right-radius: 200%;
  }
  .tit{
    color: white;
    text-align: center;
    transform: translateY(-700%);
    float:inline-start;
  }
</style>


