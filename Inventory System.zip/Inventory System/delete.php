
<?php
session_start(); 
$_SESSION["logout"] = $_POST["logout"] ?? null;
  if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_SESSION["logout"])){
    $_SESSION = array();
    session_unset();
    session_destroy();
    header("Location: log_in.php");
    exit;
  } 
  if (($_SESSION["logIn"] ?? false) !== true) {
    session_unset();
    header("Location: log_in.php");
    exit;
}
include("dataBase.php"); 
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["yes"])) {
    $email = $_SESSION["username"];
    if (isset($email)) {
        $email = $_SESSION["username"]; 
        $sql = "DELETE FROM `users info` WHERE `Email Address` = ?";
        $stmt = mysqli_prepare($conn, $sql);

        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "s", $email); 
            if (mysqli_stmt_execute($stmt)) {
                if (mysqli_stmt_affected_rows($stmt) > 0) {
                    header("location: main.php");
                    $email = null;
                }
            } else {
                echo "Error executing query: " . mysqli_error($conn);
            }
            mysqli_stmt_close($stmt);
        } else {
            echo "Error preparing statement: " . mysqli_error($conn);
        }
    } else {
        echo "{$email} not Found!.";
    }
}

if(isset($_POST["errbutton"])) {
    header("location: settings.php");
}
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete</title>
    <link rel="icon" type="image/png" href="newLogo.png">
</head>
<body>
    <form action="delete.php" method="post" class="notify">
        <h4>Are you sure you want to delete your account?</h4>
        <button class="errbutton" name="yes">Yes</button>
        <button class="errbutton" name="errbutton">No</button>
    </form>
</body>
</html>

<style>
   body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #2C3E50;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
}

.notify {
    background-color: #34495e;
    width: 320px;
    padding: 30px;
    color: white;
    text-align: center;
    margin: auto;
    border-radius: 12px;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3);
}

.notify h4 {
    font-size: 20px;
    margin-bottom: 20px;
}

.errbutton {
    font-size: 16px;
    padding: 12px 20px;
    width: 100px;
    border-radius: 8px;
    margin: 10px;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.2s ease;
}

.errbutton:hover {
    background-color: #e74c3c;
    color: white;
    transform: scale(1.05);
}

.errbutton[name="errbutton"]:hover {
    background-color: #27ae60;
    color: white;
}

.errbutton:active {
    transform: scale(0.98);
}

.errbutton[name="yes"] {
    background-color: #e74c3c;
}

.errbutton[name="errbutton"] {
    background-color: #27ae60;
}

</style>