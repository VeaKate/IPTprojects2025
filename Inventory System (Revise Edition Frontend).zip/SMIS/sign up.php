

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign up</title>
    <link rel="icon" type="image/png" href="newLogo.png">
    <link rel="stylesheet" href="style.css">
</head>
<body class="sign_up_body">
    <div class="form">
        <form action="sign_up.php" method="post">
        <div><label  class="label">First Name:</label> <input type="text" id="fName" class="input" name="fName" required></div><br><br>
        <div><label  class="label">Last Name:</label> <input type="text" id="lName" class="input" name="lName" required></div><br><br>
        <div><label  class="label">Company Name:</label> <input type="text" id="company" class="input" name="company" required></div><br><br>
        <div><label  class="label">Position:</label> 
        <select id="position" class="input" name="position" required>
            <option value="Owner" name="position">Owner</option>
            <option value="CEO"  name="position">CEO</option>
            <option value="Employee"  name="position">Employee</option>
            <option value="Guess"  name="position">Guest</option>
        </select></div><br><br>
        <div><label  class="label">Email Adress:</label> <input required type="text" id="email" class="input" name="email"></div><br><br>
        <div><label  class="label">Gender:</label> 
        <label  id="gender" class="input">Male</label><input type="radio" name="gender" class="input" required value="Male">
        <label class="input">Female</label><input type="radio" name="gender" class="input" required value="Female">
        <label class="input">Custom</label><input name="gender" type="radio" gender required value="Custom"></div class="input"><br><br>
        <div><label  class="label">Birthday:</label> <input required type="date" id="bDay" class="input" name="bDay"></div><br><br>
        <div><label  class="label">Mobile/Telephone:</label> <input required type="text" id="mobile" class="input" name="contact"></div><br><br>
        <div><label  class="label">Password:</label> <input required type="password" id="pass" class="input" name="password" 
        minlength="7" maxlength="12" required></div><br><br>
        <div><label  class="label">Confirm Password:</label> <input required type="password" id="conpass" class="input"
        name="con_password" required minlength="7" maxlength="12"></div><br><br>
    <div class="button">
        <button type="submit" class="buttons" id="Create" name="create_acc" >Create Account</button>
        <a href="main.php" id="back">Back</a>
    </div>
    </p>
    </form>
</div>
</body>
</html>

<?php
    include("dataBase.php");
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["create_acc"])) {
        $fName = filter_input(INPUT_POST,"fName", FILTER_SANITIZE_SPECIAL_CHARS);
        $lName = filter_input(INPUT_POST,"lName", FILTER_SANITIZE_SPECIAL_CHARS);
        $company = filter_input(INPUT_POST,"company", FILTER_SANITIZE_SPECIAL_CHARS);
        $position = $_POST["position"] ?? '';
        $email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_SPECIAL_CHARS);
        $gender = $_POST["gender"] ?? '';
        $birthday = $_POST["bDay"] ?? ''; 
        $contact = filter_input(INPUT_POST, "contact", FILTER_SANITIZE_SPECIAL_CHARS);
        $password = filter_input(INPUT_POST,"password", FILTER_SANITIZE_SPECIAL_CHARS) ;
        $con_password = filter_input(INPUT_POST,"con_password", FILTER_SANITIZE_SPECIAL_CHARS);
        
        if(strpos($email, "@gmail.com" ) == false) {
            echo "Invalid Email! Please Enter a valid Email!";
        } 
        else if($password !== $con_password) {
            echo "Password did not Match";
        }
        else {
            $sql = "INSERT INTO `users info` (`First Name`, `Last Name`, `Company Name`, `Position`, `Email Address`, `Gender`, `Birthday`, `Mobile/Telephone`, `Password`)
                            VALUES ('$fName', '$lName', '$company', '$position', '$email', '$gender', '$birthday', '$contact', '$password')";
                            $result = mysqli_query($conn, $sql);
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            mysqli_close($conn);
            echo "New Account Created Successfully";
            header("location: log_in.php");
        }
    }
?>
<style>
    body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f5f7fa;
    margin: 0;
    padding: 0;
    
}

.form {
    background-color: #ffffff;
    width: 90%;
    max-width: 600px;
    margin: 50px auto;
    padding: 30px 20px;
    border-radius: 10px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
    border: 2px solid #000000;
    
}

.label {
    font-size: 18px;
    display: inline-block;
    width: 200px;
    text-align: left;
    margin-bottom: 8px;
    font-weight: bold;
    color: #1a237e;
}

.input {
    width: 60%;
    font-size: 16px;
    padding: 10px;
    margin: 8px 0;
    border: 1px solid #ccc;
    border-radius: 6px;
    box-sizing: border-box;
}

.input[type="radio"] {
    width: auto;
    margin-left: 10px;
    margin-right: 5px;
}

.button {
    text-align: center;
    margin-top: 30px;
}

.buttons, #back {
    padding: 12px 24px;
    font-size: 18px;
    border: none;
    border-radius: 30px;
    cursor: pointer;
    margin: 10px;
    transition: background-color 0.3s ease;
}

#Create {
    background-color: #3949ab;
    color: white;
    font-weight: bold;
}

#Create:hover {
    background-color: #1e88e5;
}

#back {
    background-color: #aed581;
    color: #000;
    text-decoration: none;
}

#back:hover {
    background-color: #9ccc65;
}

#errMessage {
    color: red;
    font-weight: bold;
}

@media (max-width: 768px) {
    .form {
        width: 90%;
        padding: 20px;
    }

    .label {
        width: 100%;
        margin-bottom: 5px;
    }

    .input {
        width: 100%;
    }
}

</style>