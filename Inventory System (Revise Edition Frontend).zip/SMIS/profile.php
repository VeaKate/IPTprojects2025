
<?php
    include("header.php");
?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>profile.com</title>
        <link rel="icon" type="image/png" href="newLogo.png">
    </head>
    <body>
        <h1>Profile</h1>
        <div class="content">
        <img src="prof_sample.jpg" id="prof.pic" align="center" style="max-height: 200px;
        width: 200px; ">
        <form action="profile.php" method="post">
        <pre>Name: Dasha Taran</pre>
        <pre>Age: 24</pre>
        <pre>Status: Single</pre>
        <pre>Company: Telegram</pre>
        <pre>Position: CEO</pre>
        <pre>Email: example34@gmail.com</pre>
        <pre>Gender: Female</pre><br><br>
        <pre>Upload Photo: <input type="file" id="upload" name="prof"></pre><br>
        <button id="but" type="submit" >Change Profile</button>
        </form>
        </div>
    <script src="prof.js"></script>
    </body>
    </html>

<style>
    body {
        background-color: #ecf0f1;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        margin: 0;
        padding: 0;
        text-align: center;
        color: #2c3e50;
    }

    h1 {
        margin-top: 40px;
        color: #2980b9;
        font-size: 36px;
    }

    .content {
        background-color: #ffffff;
        border: 1px solid #ccc;
        border-radius: 15px;
        padding: 30px;
        margin: 40px auto;
        width: 90%;
        max-width: 600px;
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
    }

    #prof\.pic {
        border-radius: 50%;
        height: 180px;
        width: 180px;
        border: 4px solid #2980b9;
        margin-bottom: 20px;
    }

    pre {
        font-size: 18px;
        color: #34495e;
        text-align: left;
        margin: 10px auto;
        width: fit-content;
        font-weight: 500;
    }

    input[type="file"] {
        padding: 5px;
        border-radius: 5px;
        border: 1px solid #bdc3c7;
        background-color: #fdfdfd;
        margin-left: 10px;
    }

    #but {
        font-size: 16px;
        padding: 10px 20px;
        border-radius: 25px;
        border: none;
        background-color: #27ae60;
        color: white;
        font-weight: bold;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    #but:hover {
        background-color: #c0392b;
    }
</style>
