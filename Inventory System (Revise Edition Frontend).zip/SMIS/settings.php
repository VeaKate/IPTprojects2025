
<?php
    include("header.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings</title>
    <link rel="icon" type="image/png" href="newLogo.png">
</head>
<body>
    <form action="settings.php" method="post">
        <div class="butt">
        <button class="reset" id="edit" name="edit">Edit Information</button><br><br><br>
        <button class="reset" id="delete" name="delete">Delete Account</button><br><br><br>
        <button class="reset" id="logout" name="logout">Logout</button><br><br><br>
        </div>
    </form>
    <?php
        if(isset($_POST["edit"])) {
            include("reset.php");
            echo "<style> .butt{display: none} </style>";
        }
        if(isset($_POST["delete"])) {
            include("delete.php");
        }
        if(isset($_POST["logout"])) {
            header("location: main.php");
        }

    ?>
</body>
</html>
<style>
body {
    background-color: #f9fafb;
    font-family: 'Inter', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    margin: 0;
    padding: 0;
    color: #222;
    text-align: center;
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
}

.butt {
    display: flex;
    flex-direction: column;
    gap: 10px;
    padding: 40px 35px;
    border-radius: 10px;
    background-color: #ffffff;
    max-width: 360px;
    width: 70%;
    box-shadow: 0 6px 12px rgba(0,0,0,0.1);
    border: 1px solid #000000;
    margin-left: 500px;
}

.reset {
    width: 100%;
    font-size: 18px;
    padding: 14px 0;
    border-radius: 8px;
    background-color: #3b82f6; /* Blue 500 */
    color: white;
    font-weight: 600;
    border: none;
    cursor: pointer;
    transition: background-color 0.25s ease;
    box-shadow: 0 3px 6px rgba(59,130,246,0.4);
}

.reset:hover {
    background-color: #2563eb; /* Blue 600 */
    box-shadow: 0 5px 12px rgba(37,99,235,0.6);
}

#logout {
    background-color: #ef4444; /* Red 500 */
    box-shadow: 0 3px 6px rgba(239,68,68,0.4);
}

#logout:hover {
    background-color: #dc2626; /* Red 600 */
    box-shadow: 0 5px 12px rgba(220,38,38,0.6);
}

</style>