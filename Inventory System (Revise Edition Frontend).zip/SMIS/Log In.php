<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Sign in</title>
<link rel="icon" type="image/png" href="newLogo.png" />
</head>
<body class="log_in_page">
  <div class="log_in_container">
    <form action="log_in.php" method="post" novalidate>
      <h2 id="log_in_head">Log in</h2>
      <label for="username">Email or Username</label>
      <input type="text" id="username" name="username" class="textbox" required autocomplete="username" />

      <label for="password">Password</label>
      <input type="password" id="password" name="password" class="textbox" required autocomplete="current-password" />

      <input type="submit" class="log_in_page_buttons" id="log_in" name="log_in" value="Log in" />
      <a href="main.php" class="log_in_page_buttons" id="Back">Back</a>
    </form>

    <?php
    include("dataBase.php");

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["log_in"])) {
        $username = $_POST["username"] ?? '';
        $password = $_POST["password"] ?? '';

        $sql = "SELECT `Email Address`, `Password` FROM `users info` WHERE `Email Address` = ? AND `Password` = ?";
        $stmt = mysqli_prepare($conn, $sql);

        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "ss", $username, $password);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);

            if (mysqli_num_rows($result) > 0) {
                $_SESSION["username"] = $username;
                $_SESSION["password"] = $password;
                header("location: dashboard.php");
                exit();
            } else {
                echo '<p class="error-msg">Credentials not found! 😥</p>';
            }

            mysqli_stmt_close($stmt);
        } else {
            echo '<p class="error-msg">Error preparing statement: ' . mysqli_error($conn) . '</p>';
        }

        mysqli_close($conn);
    }
    ?>
  </div>
</body>
</html>

<style>

  body.log_in_page {
    background-color: #f5f7fa;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    margin: 0; 
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    color: #333;
  }

  .log_in_container {
    background: white;
    padding: 40px 50px;
    border-radius: 15px;
    box-shadow: 0 6px 18px rgba(0,0,0,0.1);
    width: 350px;
    box-sizing: border-box;
    text-align: center;
  }

  h2#log_in_head {
    margin-bottom: 30px;
    font-weight: 700;
    color: #00796b;
  }

  label {
    display: block;
    margin-bottom: 6px;
    font-weight: 600;
    text-align: left;
  }

  input.textbox {
    width: 100%;
    padding: 12px 15px;
    font-size: 16px;
    border: 1.8px solid #ccc;
    border-radius: 8px;
    margin-bottom: 20px;
    transition: border-color 0.3s ease;
    box-sizing: border-box;
  }

  input.textbox:focus {
    border-color: #00796b;
    outline: none;
  }

  input.log_in_page_buttons, a.log_in_page_buttons {
    display: inline-block;
    width: 100%;
    padding: 12px 0;
    margin-top: 10px;
    border-radius: 30px;
    font-weight: 600;
    font-size: 16px;
    cursor: pointer;
    text-decoration: none;
    box-sizing: border-box;
    user-select: none;
    border: none;
    transition: background-color 0.3s ease;
  }

  input#log_in {
    background-color: #00796b;
    color: white;
    border: none;
    margin-bottom: 20px;
  }

  input#log_in:hover {
    background-color: #004d40;
  }

  a#Back {
    background-color: #d32f2f;
    color: white;
    text-align: center;
  }

  a#Back:hover {
    background-color: #b71c1c;
  }

  .error-msg {
    margin-top: 15px;
    color: #d32f2f;
    font-weight: 700;
  }
</style>
