<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dash Board</title>
    <link rel="icon" type="image/png" href="newLogo.png">
</head>
<body>
    <h1>Tally Sheet Table</h1>
    <main class="right-con">
        <aside class="ass">
            <h6>Please Fill Out The Following:</h6>
            <form action="dashboard.php" method="post">
                <input type="text" class="input" placeholder="Enter Product Name...." name="product_name"><br><br>
                <input type="number" class="input" placeholder="Stock...." name="stock"><br><br>
                <input type="number" step="0.01" class="input" placeholder="Product Price...." name="price"><br><br>
                <input type="number" class="input" placeholder="Sold Out...." name="sold"><br><br>
                <button id="button" type="submit" class="input" name="reg">Register</button>
            </form>
        </aside>
        
        <div class="tabs">
            <table>
                <tr align="center">
                    <th width="150">Product Name</th>
                    <th width="150">Stock</th>
                    <th width="150">Product Price</th>
                    <th width="150">Sold Out</th>
                    <th width="150"></th>
                </tr>
                <tr align="center">
                    <td class="data" name="table-data"><?php foreach ($_SESSION['product_name'] as $input) {
                        echo "<h6>" . htmlspecialchars($input) . "</h6>";
                    } ?></td>
                    <td class="data" name="table-data"><?php foreach ($_SESSION['stock'] as $input) {
                        echo "<h6>" . htmlspecialchars($input) . "</h6>";
                    } ?></td>
                    <td class="data" name="table-data"><?php foreach ($_SESSION['price'] as $input) {
                        echo "<h6>₱" . htmlspecialchars($input) . "</h6>";
                    } ?></td>
                    <td class="data"><?php foreach ($_SESSION['sold'] as $input) {
                        echo "<h6>" . htmlspecialchars($input) . "</h6>";
                    } ?></td>
                    <td><?php foreach ($_SESSION['product_name'] as $index => $input) {
                        echo "<h6><form method='post' action='dashboard.php' style='display:inline;'>
                            <input type='hidden' name='index' value='$index'>
                            <button type='submit' id='del_but' name='delete_input'>Delete</button>
                        </form></h6>";
                    } ?></td>
                </tr>
            </table>
        </div>
    </main>

    <!-- Calculate Button Moved Below Table -->
    <div style="text-align: center; margin-top: 20px;">
        <a href="verification.php">
            <button id="calcButton">Calculate</button>
        </a>
    </div>
</body>
</html>

<style>
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f5f7fa;
    color: #333;
    margin: 0;
    padding: 0;
    
}

h1 {
    color: #1a237e;
    margin-top: 20px;
}

main.right-con {
    display: flex;
    justify-content: space-between;
    padding: 20px;
}

aside.ass {
    width: 30%;
    background-color: #ffffff;
    padding: 25px;
    border-radius: 0px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    border: 2px solid #000000;
}

.ass h6 {
    font-size: 18px;
    margin-bottom: 10px;
}

.input {
    width: 90%;
    font-size: 16px;
    padding: 12px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 8px;
    box-sizing: border-box;
    border: 1px solid #000000;
    
}

#button {
    width: 90%;
    padding: 14px;
    font-size: 18px;
    background-color: #3949ab;
    color: white;
    border: none;
    border-radius: 25px;
    cursor: pointer;
    font-weight: bold;
}

#button:hover {
    background-color: #1e88e5;
}

.tabs {
    width: 80%;
    background-color: #ffffff;
    border-radius: 0px;
    box-shadow: 0 0 12px rgba(0, 0, 0, 0.08);
    padding: 20px;
    overflow-y: auto;
    max-height: 480px;
    border: 2px solid #000000;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th {
    font-size: 18px;
    background-color: #e3f2fd;
    padding: 12px;
    color: #1a237e;
    border-bottom: 2px solid #cfd8dc;
}

td {
    font-size: 16px;
    padding: 10px;
    border-bottom: 1px solid #e0e0e0;
}

.data h6 {
    margin: 5px 0;
    font-weight: normal;
}

#del_but {
    background-color: #e53935;
    color: white;
    border: none;
    padding: 5px 12px;
    border-radius: 5px;
    cursor: pointer;
}

#del_but:hover {
    background-color: #d32f2f;
}

#calcButton {
    margin-top: 0px;
    padding: 15px;
    width: 300px;
    font-size: 18px;
    font-weight: bold;
    background-color: #3949ab;
    color: white;
    border: none;
    border-radius: 100px;
    cursor: pointer;
    margin-left: 200px;
}

#calcButton:hover {
    background-color: #1e88e5;
}
</style>
