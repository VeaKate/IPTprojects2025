<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Verify</title>
<link rel="icon" type="image/png" href="newLogo.png" />
</head>
<body>
<form action="verification.php" method="post">
  <h3>Verification❗</h3>
  <p>We need to verify it's you before you can proceed.</p>
  <h4>Please enter your password first</h4>
  <input name="password" type="password" placeholder="Your password" required autofocus />
  <div class="buttons">
    <button name="back" type="submit">Back</button>
    <button name="verify" type="submit">Verify</button>
  </div>

  <?php
    $email = $_SESSION["username"] ?? '';
    $password = $_SESSION["password"] ?? '';

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['verify'])) {
        if (!isset($_POST["password"]) || $_POST["password"] === '' || $_POST["password"] !== $password) {
            echo "<p class='error-msg'>Password is Invalid!</p>";
        } else {
            header("Location: calcResult.php");
            exit();
        }
    }

    if (isset($_POST['back'])) {
        header("Location: dashboard.php");
        exit();
    }
  ?>
</form>

<style>
  /* Reset and base */
  body, html {
    margin: 0;
    padding: 0;
    height: 100%;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #00796b;
    color: white;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  form {
    background-color: #121212;
    padding: 30px 40px;
    border-radius: 12px;
    box-shadow: 0 6px 18px rgba(0, 0, 0, 0.7);
    text-align: center;
    max-width: 360px;
    width: 90%;
  }

  h3 {
    margin-bottom: 10px;
    font-weight: 700;
  }

  h4 {
    margin-top: 15px;
    margin-bottom: 25px;
    font-weight: 500;
  }

  input[type="password"] {
    width: 100%;
    padding: 12px;
    font-size: 16px;
    border-radius: 8px;
    border: none;
    outline: none;
    box-sizing: border-box;
  }

  input[type="password"]:focus {
    box-shadow: 0 0 5px #26a69a;
  }

  .buttons {
    margin-top: 25px;
    display: flex;
    justify-content: space-between;
    gap: 10px;
  }

  button {
    flex: 1;
    padding: 10px 0;
    border-radius: 8px;
    border: none;
    font-weight: 600;
    font-size: 14px;
    cursor: pointer;
    transition: background-color 0.25s ease;
  }

  button[name="back"] {
    background-color: #555;
    color: #ddd;
  }

  button[name="back"]:hover {
    background-color: #444;
  }

  button[name="verify"] {
    background-color: #26a69a;
    color: white;
  }

  button[name="verify"]:hover {
    background-color: #1e847f;
  }

  .error-msg {
    margin-top: 20px;
    color: #ff6b6b;
    font-weight: 600;
  }
</style>
</body>
</html>
