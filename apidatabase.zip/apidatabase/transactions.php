<?php
include("dataBase.php");
header('Content-Type: application/json'); 

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); 
    echo json_encode(['error' => 'Method Not Allowed. Use POST.']);
    exit;
}

$API_Key = "oihdobvj784734qoryqt7tw9w47tw9w7tw8w9";

$input = json_decode(file_get_contents('php://input'), true);
  $email = $input["username"] ?? null;
    $product_stocks = $input["Product_Stocks"] ?? null;
    $daily_earnings = $input["Daily_Earnings"] ?? null;
    $daily_sold_out = $input["Daily_Sold_Out"] ?? null;
    $Date = $input["Date"] ?? null;
    $City = $input["City"] ?? null;
    $key = $input["API_Key"] ?? null;

    if (isset($email, $product_stocks, $daily_earnings, $daily_sold_out, $Date, $City, $key)) {
        if ($key === $API_Key) {
            try {
                $stmt = $conn->prepare("INSERT INTO sales_tally(Email, Product_Stocks, Daily_Earnings, Daily_Sold_Out, Date, City)
                                        VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("sddsss", $email, $product_stocks, $daily_earnings, $daily_sold_out, $Date, $City);
                if ($stmt->execute()) {
                    echo json_encode(['success' => 'Transaction recorded successfully.']);
                } else {
                    echo json_encode(['error' => 'Failed to record transaction.']);
                }
            } catch (Exception $e) {
                echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
            }
        } else {
            echo json_encode(['error' => 'Invalid API Key.']);
        }
    } else {
        echo json_encode(['error' => 'Missing required fields.']);
    }
  
?>