<?php
    include("dataBase.php");
include("dataBase.php");
header('Content-Type: application/json'); 

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); 
    echo json_encode(['error' => 'Method Not Allowed. Use POST.']);
    exit;
}

$API_Key = "oihdobvj784734qoryqt7tw9w47tw9w7tw8w9";

$input = json_decode(file_get_contents('php://input'), true);
  $firstName = $input["firstname"] ?? null;
    $lastName = $input["lastname"] ?? null;
    $Companny = $input["company"] ?? null;
    $position = $input["position"] ?? null;
    $gender = $input["gender"] ?? null;
    $birthday = $input["birthday"] ?? null;
    $contact = $input["tel/phone"];
    $email = $input["email"] ?? null;
    $key = $input["API_Key"] ?? null;

    if (isset($email, $product_stocks, $daily_earnings, $daily_sold_out, $Date, $City, $key)) {
        if ($key === $API_Key) {
            try {
                $stmt = $conn->prepare("UPDATE users_info 
        SET first_name = ?, 
            last_name = ?, 
            company_name = ?, 
            position = ?, 
            gender = ?, 
            birthday = ?, 
            mobile_telephone = ? 
        WHERE email_address = ?");
                $stmt->bind_param("sssssss", $firstName, $lastName, $Company, $position, $gender, $birthday, $contact);
                if ($stmt->execute()) {
                    echo json_encode(['success' => 'Transaction recorded successfully.']);
                } else {
                    echo json_encode(['error' => 'Failed to record transaction.']);
                }
            } catch (Exception $e) {
                echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
            }
        } else {
            echo json_encode(['error' => 'Invalid API Key.']);
        }
    } else {
        echo json_encode(['error' => 'Missing required fields.']);
}  
?>
