<?php
$db_server = "localhost";
$db_user = "root";
$db_pass = "admin123";
$db_name = "emailverification";
$db_port = 3307;
$conn = "";

try{
$conn = mysqli_connect($db_server, $db_user,
                       $db_pass, $db_name, $db_port);
} catch(Exception $e){
    echo $e->getMessage();
}
?>