from django.shortcuts import render

# Create your views here.
from django.http import JsonResponse
from django.utils import timezone

def current_time(request):
    now = timezone.now()
    response_data = {
        'current_time': now.strftime("%Y-%m-%d %H:%M:%S"),
        'timezone': 'Asia/Manila'
    }
    return JsonResponse(response_data)