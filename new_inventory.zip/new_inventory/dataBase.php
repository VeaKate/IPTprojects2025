<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
$db_server = "localhost";
$db_user = "root";
$db_pass = "admin123";
$db_name = "emailverification";
$db_port = 3307;
$conn = "";

try{
$conn = mysqli_connect($db_server, $db_user,
                       $db_pass, $db_name, $db_port);
} catch(Exception $e){
    echo $e->getMessage();
}
?>