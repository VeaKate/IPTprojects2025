<?php
   include("header.php");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
    if (!isset($_SESSION["username"])) {
        header("Location: main.php"); 
        exit();
    }
?>
<!--Html-->
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>History</title>
    <link rel="icon" type="image/png" href="newLogo.png">
    </head>
    <body></body>
    <hr>
   <?php
include("dataBase.php");

if (isset($_SESSION['username'])) {
    $email = $_SESSION['username'];
    $sql = "SELECT * FROM sales_tally WHERE Email = ?";
    $stmt = mysqli_prepare($conn, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<div class='rec'>";
                echo "<p>Current Stocks: " . htmlspecialchars($row['Product_Stocks']) . "</p>";
                echo "<p>Current Earnings: " . htmlspecialchars($row['Daily_Earnings']) . "</p>";
                echo "<p>Sold Out: " . htmlspecialchars($row['Daily_Sold_Out']) . "</p>";
                echo "<p>Date: " . htmlspecialchars($row['Date']) . "</p>";
                // Form to delete the record
                echo "<form id='hist' method='post' action='history.php'>";
                echo "<input type='hidden' name='date' value='" . htmlspecialchars($row['Date']) . "'>"; // Hidden input for the date
                echo "<button type='submit' id='but' name='delete_input' class='but'>Delete</button>";
                echo "</form>";
                echo "</div>";
                echo "<hr>";
            }
        } else {
            echo "<div class='rec'>No transactions found.</div>";
        }

        mysqli_stmt_close($stmt);
    } else {
        echo "Error preparing statement: " . mysqli_error($conn);
    }

    // Handle deletion logic
    if (isset($_POST['delete_input'])) {
        $dateToDelete = $_POST['date']; // Get the date from the hidden input

        // Prepare the DELETE statement
        $deleteSql = "DELETE FROM sales_tally WHERE Email = ? AND Date = ?";
        $deleteStmt = mysqli_prepare($conn, $deleteSql);

        if ($deleteStmt) {
            mysqli_stmt_bind_param($deleteStmt, "ss", $email, $dateToDelete);
            if (mysqli_stmt_execute($deleteStmt)) {
                echo "<script>alert('Record deleted successfully!');</script>";
                header("Location: history.php"); // Redirect to the same page to refresh the data
                exit();
            } else {
                echo "Error deleting record: " . mysqli_error($conn);
            }
            mysqli_stmt_close($deleteStmt);
        } else {
            echo "Error preparing delete statement: " . mysqli_error($conn);
        }
    }
} else {
    echo "<div class='rec'>Please log in to view your transaction history.</div>";
}

mysqli_close($conn);
?>
    </body>
</html>

<style>
    #trans{
    margin-top: -35px;
    font-size: 30px;
    background-color:blue;
    color: white;
    padding: 30px;
    animation-name: animate;
    }
    .button{
    float: right;
    }
    .rec{
    margin: 20px;
    font-size: 15px;
    text-align: center;
    color: black;
    background-color: aliceblue;
    }
    .rec p, #but, #hist{
        display: inline-block;
        padding: -50px;
        margin: 20px;
    }
    .but{
    width: 120px;
    height: 35px;
    font-weight: bold;
    background-color: rgb(250, 4, 4);
    color: white;
    border: none;
    border-radius: 20px;
    }
    body{
    margin: 0px;
    background-color: rgb(0, 128, 107);
    }