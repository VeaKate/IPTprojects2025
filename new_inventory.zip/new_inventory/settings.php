<?php
   include("header.php");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
    if (!isset($_SESSION["username"])) {
        header("Location: main.php"); 
        exit();
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings-</title>
</head>
<body class="setb">
    <div class="set">
        <h5 style="text-align: center;">Change Info</h5>
        <form action="settings.php" method="post">
            <label for="fName">First Name</label><br>
    <input type="text" name="fName" required><br>
     <label for="lName">Last Name</label><br>
    <input type="text" name="lName" required><br>
     <label for="position">Position</label><br>
    <input type="text" name="position" list="position" required><br>
    <datalist id="position">
        <option value="Owner">Owner</option>
        <option value="CEO">CEO</option>
        <option value="Employee">Employee</option>
        <option value="Guest">Guest</option>
    </datalist>
    <label for="company">Company Name</label><br>
    <input type="text" name="company" required><br>
    <label for="email">Email Address</label><br>
    <input type="email" name="email" required><br>
    <label for="gender">Gender</label><br>
    <input type="text" name="gender" list="gender" required><br>
    <datalist id="gender">
        <option value="Male">Male</option>
        <option value="Female">Female</option>
    </datalist>
    <label for="bDay">Birthdate</label><br>
    <input type="date" name="bDay" required><br>
    <label for="contact">Mobile/Telephone</label><br>
    <input type="tel" name="contact" required><br><br><br>
    <button type="submit" class="buttons" id="Create" name="edit" >Edit Information</button><br>
    or
    <br>
    <button class="buttons" id="del">Delete Account</button>
        </form>
    </divt>
</body>
</html>
<?php
    if(isset($_POST["del"])) {
        $API_kEY = "oihdobvj784734qoryqt7tw9w47tw9w7tw8w9";
        $email = $_SESSION["username"];

        $ch = curl_init('http://localhost/apaidatabase/delete.php');

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
            'email' => $email,$API_Key = "oihdobvj784734qoryqt7tw9w47tw9w7tw8w9",
            'API_Key' => $API_kEY
        ]));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER,[
            'Content-Type: application/json',
        ]);
        $response = curl_exec($ch);

        if ($response === false) {
            echo 'Curl error: ' . curl_error($ch);
        } else {
            echo "Account deleted successfully.";
            session_destroy();
            header("Location: index.php");
            exit();
        }
        curl_close($ch);

    }
    if(isset($_POST["edit"])) {
        $first_name = $_POST["fName"] ?? null;
         $last_name = $_POST["lName"] ?? null;
         $position = $_POST["position"] ?? null;
          $comapny = $_POST["company"] ?? null;
           $email = $_POST["email"] ?? null;
            $gender = $_POST["gender"] ?? null;
             $birthday = $_POST["bDay"] ?? null;
             $contact = $_POST["contact"] ?? null;
             $API_kEY = "oihdobvj784734qoryqt7tw9w47tw9w7tw8w9";
            $email = $_SESSION["username"];

            $ch = curl_init('http://localhost/apaidatabase/edit.php');

            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
                'firstname' => $first_name,
                'lastname' => $last_name,
                'company' => $comapny,
                'position' => $position,
                'gender' => $gender,
                'birthday' => $birthday,
                'tel/phone' => $contact,
                'email' => $email,
                'API_KEY' => $API_kEY
            ]));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER,[
                'Content-Type: application/json',
            ]);
        $response = curl_exec($ch);

if ($response === false) {
    echo 'Curl error: ' . curl_error($ch);
}
curl_close($ch);
    }
?>
<style>
    .setb{
        margin: 0px;
        background-color: hsl(199, 76.30%, 63.50%);
        height: 100vh;
        overflow: hidden;
    }
    .set input{
        width: 250px;
        outline : none;
    }
    .buttons{
        font-size: 15px;
        padding: 10px;
        background-color:rgb(33, 207, 27);
    }
    #del{
        background-color: red;
        color: white;
    }
    .set{
        text-align: left;
        display: inline-block;
        background-color: white;
        width: 250px;
        height: 500px;
        margin: 0 auto;
        color: black;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
</style>