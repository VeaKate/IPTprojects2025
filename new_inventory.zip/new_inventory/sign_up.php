<?php
session_start();
 $password = filter_input(INPUT_POST, "password", FILTER_SANITIZE_SPECIAL_CHARS);
$confirm_password = filter_input(INPUT_POST, "con_password", FILTER_SANITIZE_SPECIAL_CHARS);
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST["create_acc"])) {
    if ($password != $confirm_password) {
        $_SESSION["err"] = "<p style='color:red'>Warning: Password did not Match</p>";
        header("location: sign_up.php");
        exit;
    }
    $fName = filter_input(INPUT_POST, "fName", FILTER_SANITIZE_SPECIAL_CHARS);
    $lName = filter_input(INPUT_POST, "lName", FILTER_SANITIZE_SPECIAL_CHARS);
    $company = filter_input(INPUT_POST, "company", FILTER_SANITIZE_SPECIAL_CHARS);
    $position = filter_input(INPUT_POST, "position", FILTER_SANITIZE_SPECIAL_CHARS);
    $user_email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_EMAIL);
    $gender = filter_input(INPUT_POST, "gender", FILTER_SANITIZE_SPECIAL_CHARS);
    $birthday = filter_input(INPUT_POST, "bDay", FILTER_SANITIZE_SPECIAL_CHARS);
    $contact = filter_input(INPUT_POST, "contact", FILTER_SANITIZE_NUMBER_INT);
    $_SESSION["email"] = $user_email;
    $_SESSION["fName"] = $fName;
    $_SESSION["lName"] = $lName;
    $_SESSION["company"] = $company;
    $_SESSION["position"] = $position;
    $_SESSION["gender"] = $gender;
    $_SESSION["birthday"] = $birthday;
    $_SESSION["contact"] = $contact;
    $_SESSION["password"] = $password;
    include("emailver.php");
    include("check.php");
    header("location: verifysignup.php");
    exit; 
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign up</title>
    <link rel="icon" type="image/png" href="newLogo.png">
    <link rel="stylesheet" href="style.css">
</head>
<body class="sign_up_body">
    <div class="form">
        <form class="formsign" action="sign_up.php" method="post">
        <?php
        if (isset($_SESSION["err"])) {
            echo $_SESSION["err"];
            unset($_SESSION["err"]);
        }
        ?>
        <?php
        if (isset($_SESSION["err2"])) {
            echo $_SESSION["err2"];
            unset($_SESSION["err2"]);
        }
        ?>
    <label for="fName">First Name</label><br>
    <input type="text" name="fName" required><br>
     <label for="lName">Last Name</label><br>
    <input type="text" name="lName" required><br>
     <label for="position">Position</label><br>
    <input type="text" name="position" list="position" required><br>
    <datalist id="position">
        <option value="Owner">Owner</option>
        <option value="CEO">CEO</option>
        <option value="Employee">Employee</option>
        <option value="Guest">Guest</option>
    </datalist>
    <label for="company">Company Name</label><br>
    <input type="text" name="company" required><br>
    <label for="email">Email Address</label><br>
    <input type="email" name="email" required><br>
    <label for="gender">Gender</label><br>
    <input type="text" name="gender" list="gender" required><br>
    <datalist id="gender">
        <option value="Male">Male</option>
        <option value="Female">Female</option>
    </datalist>
    <label for="bDay">Birthdate</label><br>
    <input type="date" name="bDay" required><br>
    <label for="contact">Mobile/Telephone</label><br>
    <input type="tel" name="contact" required><br>
    <label for="password">Password</label><br>
    <input type="password" name="password" minlength="7" maxlength="12" required><br>
    <label for="con_password">Confirm Password</label><br>
    <input type="password" name="con_password" minlength="7" maxlength="12" required><br><br>
    <button type="submit" class="buttons" id="Create" name="create_acc" >Create Account</button>
    <a href="main.php" id="back">Back</a>
     <p>Already have an Account? <a href="log_in.php">Login</a></p>
    </form>
</div>
<div class="logo">
    <img id="logo" src="newLogo.png" alt="logo" width="400" height="400"><br><br>
    <h3>Streamline Your Stock, Maximize Your Success!</h3>
   <br><br><br><br>
</div>
</body>
</html>
<style>
    *{
        margin: 0;
    }
    .logo{
        display: inline-block;
        color: white;
        font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
    }
    .form{
        display: inline-block;
        place-items: center;
        margin: 40px;
        box-shadow: 0 0 20px rgba(1, 1, 26, 0.5);
    }
    .sign_up_body{
        overflow: hidden;
    justify-content: center;
    text-align: center;
    background-color: rgb(0, 128, 107);
    }
    .formsign {
        transform: translateY(-5%);
        font-size: 16px;
        display: inline-block;
        padding: 10px;
        font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
        text-align: left;
        width: 300px;
        margin: 0 auto;
        padding: 20px;
        background-color:white;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }
    .formsign #Create {
        text-align: center;
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    .formsign #Create:hover {
        background-color: #45a049;
        font-weight: bold;
    }
    .formsign #back {
        text-decoration: none;
        color: white;
        margin-left: 10px;
        padding: 10px 20px;
        background-color: #f44336;
        border-radius: 5px;
        height: 15px
    }
    .formsign input{
        outline: none;
        padding: 5px;
        width: 300px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }
    .formsign input:focus {
        transition: all 0.3s ease-in-out;
        border-color: blue;
        box-shadow: 0 0 10px rgba(0, 0, 255, 0.5);
    }
</style>

