<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify</title>
</head>
<body>
    <link rel="icon" type="image/png" href="newLogo.png">
    <h1>Verification!</h1>
    <img src="newLogo.png" alt="logo" width="200" height="200">
    <p>We need to verify it's you before you can proceed.</p>
    <form class="verify" action="verifysignup.php" method="post">
        <?php
        if (isset($_SESSION["err3"])) {
            echo "<h4>" . $_SESSION["err3"] . "</h4>";
            unset($_SESSION["err3"]); 
        }
        ?>
        <h4>Enter the code that we sent to your email</h4>
        <input type="number" name="code" required><br><br>
        <button type="submit" name="verify" id="verify">Verify</button>
        <a href="sign_up.php" id="back">Back</a>
    </form>
</body>
</html>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["verify"])) {
    $_SESSION["code"] = filter_input(INPUT_POST, "code", FILTER_SANITIZE_NUMBER_INT);
   include("try.php");
}
?>

<style>
    body {
        color: white;
        place-items: center;
        float: center;
        text-align: center;
        justify-content: center;
        margin: 0 auto;
        background-color: rgb(0, 128, 107);
    }
    input {
        font-size: 12px;
        padding: 5px;
        width: 300px;
        border-radius: 5px;
        outline: none;
        height: 20px;
        border: 1px solid #ccc;
    }
    input:focus {
        border-color: red;
        transition: border-color 0.3s ease solid 3px;
        box-shadow: 0 0 5px rgba(255, 0, 0, 0.5);
    }
    #verify:hover {
        background-color: green;
        color: white;
        font-weight: bold;
        transition: background-color 0.3s ease;
    }
    #back {
        background-color: white;
        color: black;
        font-weight: bold;
        text-decoration: none;
        padding: 8px;
        border-radius: 5px;
    }
    #back:hover {
        background-color: red;
        color: white;
        font-weight: bold;
        transition: background-color 0.3s ease;
    }
    button {
        font-size: 25px;    
        padding: 5px;
        width: 100px;
        border-radius: 5px;
        border: none;
        margin: 10px;
    }
    .verify {
        font-size: 20px;
        width: 400px;
        padding: 10px;
        border-radius: 10px;
        text-align: center;
        background-color: black;
        color: white;
        padding: 15px;
    }
</style>
