<?php
session_start();
$email = $_SESSION["email"] ?? '';
$subject = 'Verify';
$domain = 'Daily Sales Invetory Management System';
$subject = "Verification";
$sender_email = 'marketingj786@gmail.com';
$sender_password = 'orxk bcjn eqdf nzsb';

$ch = curl_init('http://localhost/api/emailverify.php');

curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
    'email' => $email,
    'domain_name' => $domain,
    'subject' => $subject,
    'sender_email' => $sender_email,
    'sender_password' => $sender_password,
    'API_Key' => 'hifuhgwqet529689ty2y630936jg&*^7'
]));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
]);

$response = curl_exec($ch);
if ($response === false) {
    echo 'Curl error: ' . curl_error($ch);
} else {
    $responseData = json_decode($response, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
    } else {
        if (isset($responseData['success']) && $responseData['success'] === true) {
            echo 'Verification email sent successfully.';
        } else {
           /// $error = $responseData['error'] ?? 'Unknown error occurred.';
           // echo 'Failed to send verification code: ' . htmlspecialchars($error);
        }
    }
}