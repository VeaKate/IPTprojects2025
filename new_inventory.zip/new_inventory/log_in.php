<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign in</title>
    <link rel="icon" type="image/png" href="newLogo.png">
</head>
<body>
    <div class="log_in_container">
        <form action="log_in.php" method="post" id="log">
            <h2 id="log_in_head">Log in</h2>
            <?php
            if ($_SERVER["REQUEST_METHOD"] == 'POST' && isset($_SESSION["invalid"])) {
                echo "<h4 style='color: white; text-align: center;'>" . $_SESSION["invalid"] . "</h4>";
                unset($_SESSION["invalid"]);
            }
            ?>
            <label>Email or Username</label><br>
            <input type="text" name="username" class="textbox" required><br><br>
            <label>Password</label><br>
            <input type="password" name="password" class="textbox" required><br><br>
            <input type="submit" class="log_in_page_buttons" id="log_in" name="log_in" value="Log in"><br><br>
            <p>Don't have an account? <a href="sign_up.php">Register</a> or</p>
            <p id="fr">Forgot your password? <a href="forgot_password.php">Reset</a></p>
        </form>
        <?php
        try{
include("dataBase.php");
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["log_in"])
&& !empty($_POST["username"]) && !empty($_POST["password"])) {
    $username = filter_input(INPUT_POST, "username", FILTER_SANITIZE_EMAIL);
    $password = filter_input(INPUT_POST, "password", FILTER_SANITIZE_SPECIAL_CHARS);

    $sql = "SELECT * FROM users_info WHERE email_address = ?";
    $stmt = mysqli_prepare($conn, $sql);
     $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if (password_verify($password, $row['password'])) {
                $_SESSION["username"] = $username;
                header("Location: dashboard.php");
                exit;
            } else {
                $_SESSION["invalid"] = "Invalid password!";
            }
        } else {
            $_SESSION["invalid"] = "No user found with that email!";
        }
        $stmt->close();
    }
        } catch (Exception $e) {
            echo "<h4 style='color: red;'>Error: " . $e->getMessage() . "</h4>";
        }
?>
    </div>
    <div class="logo">
    <img id="logo" src="newLogo.png" alt="logo" width="400" height="400"><br><br>
    <h3>Streamline Your Stock, Maximize Your Success!</h3>
</div>
</body>
</html>
<style>
    .log_in_container{
        display: inline-block;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }
    log_in_container p{
        text-align: center;
    }
    .logo{
        margin-left: 180px;
        transform: translateY(20%);
        display: inline-block;
        color: white;
        font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
    }
    #log_in{
        background-color:rgba(63, 143, 66, 0.71);
        color: white;

    
    }
    body{
        text-align: 0;
        background-color: rgb(0, 128, 107);
        overflow: hidden;
    }
    #log{
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.97);
        font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
        transform: translateY(10%);
        width: 300px;
        margin-left: 200px;
        margin-top: 50px;
        padding: 30px;
        border: 2px solid rgba(0, 0, 0, 0.32);
        border-radius: 30px;
        background-color:rgba(139, 133, 133, 0.53);
        text-align: left;
        
        
    }
    #log h2{
        text-align: center;
        color: #333;    
    }
    
    #log input{
        width: 90%;
        padding: 10px;
        margin: 10px 0;
        border: 1px solid #000000;
        border-radius: 5px;
        outline: none;

    
    }#log input:focus {
     border-color: blue;
     box-shadow: 0 0 10px rgba(121, 121, 199, 0.5);
    }
    #log input:hover{
       cursor: pointer;
        transform: scaleY(1.2);
        transition: all 0.3s ease-in-out;
    }
</style>