<?php
include("apidata.php");
      $sql = "DELETE FROM verify WHERE Created_At < NOW() - INTERVAL 5 MINUTE";
$delete_result = mysqli_query($conn, $sql);

if ($delete_result === false) {
    error_log("Deletion error: " . mysqli_error($conn)); 
} else {
    $affected_rows = mysqli_affected_rows($conn);
    if ($affected_rows > 0) {
        echo json_encode(['success' => "$affected_rows records deleted."]);
    } else {
        echo json_encode(['info' => 'No records older than 5 minutes to delete.']);
    }
}

?>