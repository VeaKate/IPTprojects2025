<?php
include("apidata.php");
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$receiver = $input['email'] ?? null; 
$domain_name = $input['domain_name'] ?? null; 
$code = $input['code'] ?? null;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); 
   json_encode(['error' => 'Method Not Allowed. Use POST.']);
    exit;
}
if (isset($receiver, $domain_name, $code)) {
    $sql = "SELECT * FROM verify WHERE Email = ? AND Domain = ? AND Code = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sss", $receiver, $domain_name, $code);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) > 0) {
        echo json_encode(['success' => true, 'message' => 'Email verified successfully.']);
        
        $sql = "DELETE FROM verify WHERE Email = ? AND Domain = ? AND Code = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "sss", $receiver, $domain_name, $code);
        mysqli_stmt_execute($stmt);
    } else {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid verification code or email.']);
    }
} else {
    http_response_code(400);
    echo json_encode(['error' => 'Missing required fields.']);
}
?>
