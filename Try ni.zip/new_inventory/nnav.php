<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body class="mn">
    <div id="na">
        <ul>
            <li><a href="sign_up.php"><button>Sign up</button></a></li>
            <li><a href="log_in.php"><button>Log in</button></a></li>
        </ul>
    </div>
</body>
</html>
<style>
    .mn{
        margin: 0px;
    }
    ul li{
        list-style-type: none;
        display:inline-block;
        margin-right: 20px;
    }
    button{
        padding: 10px;
        width: 100px;
        border-radius: 7px;
        border: none;
        font-weight: bold;
    }
    button:hover{
        cursor: pointer;
        width: 120px;
    }
    #na{
        transform: translateY(300px);
        background: linear-gradient(120deg,rgb(62, 120, 172) 0%,rgb(1, 242, 255) 100%);
        padding: 5px;
        text-align: right;
        width:100%;
        float:inline-start;
    }
</style>