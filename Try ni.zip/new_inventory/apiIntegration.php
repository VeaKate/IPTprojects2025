<?php
$email = 'johnlloydalcayde870@gmail.com';
$domain = 'Daily Sales Inventory';
$subject = 'Verification Code';
$sender_email = 'marketingj786@gmail.com';
$sender_password = 'orxk bcjn eqdf nzsb';
$API_Key = '9utergje04853pt9u30t390u63*/533';

$ch = curl_init('http://localhost/api/emailverify.php');

curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
    'email' => $email,
    'domain_name' => $domain,
    'subject' => $subject,
    'sender_email' => $sender_email,
    'sender_password' => $sender_password,
    'API_Key' => $API_Key
]));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
]);

$response = curl_exec($ch);

if ($response === false) {
    // Handle cURL error
    echo 'Curl error: ' . curl_error($ch);
} else {
    // Decode the JSON response
    $responseData = json_decode($response, true);

    // Check if decoding was successful
    if (json_last_error() !== JSON_ERROR_NONE) {
        echo 'JSON decode error: ' . json_last_error_msg();
    } else {
        // Check for success in the response
        if (isset($responseData['success']) && $responseData['success'] === true) {
            echo 'Verification email sent successfully.';
        } else {
            // Handle API error response
            $error = $responseData['error'] ?? 'Unknown error occurred.';
            echo 'Failed to send verification code: ' . htmlspecialchars($error);
        }
    }
}

$response = curl_exec($ch);

if ($response === false) {
    // Handle cURL error
    echo 'Curl error: ' . curl_error($ch);
} else {
    // Print the raw response for debugging
    echo 'Raw response: ' . htmlspecialchars($response) . '<br>';

    // Attempt to split the response into valid JSON objects
    $responses = explode('}{', $response);
    
    // If there are two responses, merge them into a single valid JSON object
    if (count($responses) > 1) {
        $mergedResponse = rtrim($responses[0], '}') . ',' . ltrim($responses[1], '{');
        $responseData = json_decode($mergedResponse, true);
    } else {
        $responseData = json_decode($response, true);
    }

    // Check if decoding was successful
    if (json_last_error() !== JSON_ERROR_NONE) {
        echo 'JSON decode error: ' . json_last_error_msg();
    } else {
        // Check for success in the response
        if (isset($responseData['success']) && $responseData['success'] === "Verification code sent successfully.") {
            echo 'Verification email sent successfully. Code: ' . $responseData['verification_code'];
        } else {
            // Handle API error response
            $error = $responseData['error'] ?? 'Unknown error occurred.';
            echo 'Failed to send verification code: ' . htmlspecialchars($error);
        }
    }
}

curl_close($ch);


    //header("location: verifysignup.php");
?>