<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dash Board</title>
    <link rel="icon" type="image/png" href="newLogo.png">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v3.0.6/css/line.css">
</head>
<body>
    <div class="head">
        <?php
        $ch = curl_init("http://127.0.0.1:8000/api/current-time/");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($ch);
        
        if (curl_errno($ch)) {
            echo 'cURL error: ' . curl_error($ch);
            curl_close($ch);
            exit;
        }
        
        curl_close($ch);
        
        $data = json_decode($response);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo "Error Occurred";
            exit; 
        }
        
        if (isset($data->current_time) && isset($data->timezone)) {
            $_SESSION["Date/Time"] = htmlspecialchars($data->current_time);
            $_SESSION["City"] =  htmlspecialchars($data->timezone);
            echo "Date/Time: " . htmlspecialchars($data->current_time) . " ";
            echo "City: " . htmlspecialchars($data->timezone);
        } else {
            echo "Request did not Respond.";
        }
        ?>
        <div class="nav_container">
            <a class="nav" href="dashboard.php" title="Homepage"><i class="uil uil-home" style="color: rgb(78, 78, 172)"></i></a>
            <a class="nav" href="profile.php" title="Profile"><i class="uil uil-user-circle" style="color: rgb(67, 67, 168)"></i></a>
            <a class="nav" href="history.php" title="History"><i class="uil uil-history" style="color: rgb(73, 73, 175)"></i></a>
            <a class="nav" href="settings.php" title="Settings"><i class="uil uil-setting" style="color: rgb(75, 75, 173)"></i></a>
            <a class="nav" href="log_in.php" title="Logout"><i class="uil uil-signout" style="color: rgb(77, 77, 161)"></i></a>
        </div>
    </div>

  
    <div class="bottom-back">
        <a href="main.php" class="back-button">Back</a>
    </div>
</body>
</html>

<style>

    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
    }

    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #f4f6f9;
        color: #333;
        text-align: center;
    }

    .head {
        background-color: #1f2937;
        color: #ffffff;
        padding: 20px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        margin-bottom: 30px;
    }

    .nav_container {
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
        gap: 50px;
        padding: 20px 0;
    }

    .nav {
        color: #4f46e5;
        text-decoration: none;
        transition: transform 0.2s ease, color 0.3s ease;
    }

    .nav i {
        font-size: 60px;
        background-color: #e0e7ff;
        padding: 20px;
        border-radius: 15px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
        transition: background-color 0.3s ease, color 0.3s ease;
    }

    .nav:hover i {
        background-color: #4b5ba18f;
        color: #ffffff;
        transform: scale(1.05);
    }

    .bottom-back {
        margin: 40px 0;
    }

    .back-button {
        background-color: #4f46e5;
        color: #ffffff;
        padding: 14px 30px;
        font-size: 18px;
        font-weight: bold;
        text-decoration: none;
        border-radius: 30px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        transition: background-color 0.3s ease, transform 0.2s ease;
    }

    .back-button:hover {
        background-color: #000000;
        transform: translateY(-2px);
    }

    @media (max-width: 600px) {
        .nav i {
            font-size: 40px;
            padding: 15px;
        }

        .nav_container {
            gap: 20px;
        }

        .back-button {
            font-size: 16px;
            padding: 10px 20px;
        }
    }
</style>


