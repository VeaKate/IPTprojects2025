<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
    include("dataBase.php"); 
    $code =  $_SESSION["code"] ?? ''; 
    $email =  $_SESSION["email"] ?? ''; 
    $domain_name = 'Daily Sales Invetory Management System';

    $ch = curl_init("http://localhost/api/verify.php");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
        'code' => $code,
        'email' => $email,
        'domain_name' => $domain_name,
    ]));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
    ]);

    $response = curl_exec($ch);
    if ($response === false) {
        echo 'Curl error: ' . curl_error($ch);
    } else {
        $_SESSION["res"] = '<h3>' .$response. '</h3>'; 
        $responseData = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
        } else {
            if (isset($responseData['success']) && $responseData['success'] === true) {
                echo '<h3>Verification successful!</h3>';
                include("dataBase.php");
               $user_email =  $_SESSION["email"] ?? ''; 
               $fName =   $_SESSION["fName"] ?? '';
                $lName =  $_SESSION["lName"] ?? ''; 
                $company = $_SESSION["company"] ?? ''; 
                $position = $_SESSION["position"] ?? ''; 
                $gender =  $_SESSION["gender"] ?? ''; 
                $birthday =  $_SESSION["birthday"] ?? '';
                $contact = $_SESSION["contact"] ?? ''; 
                $password =  $_SESSION["password"] ?? ''; 
                $passhash = password_hash($password, PASSWORD_DEFAULT); 
                $stmt = $conn->prepare("INSERT INTO users_info (first_name, last_name, company_name,
                 position, email_address, gender, birthday, mobile_telephone, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("sssssssss",  $fName, $lName, $company, $position, $user_email, $gender, $birthday, $contact, $passhash);  
                $stmt->execute();
                $stmt->close();
                header("location: log_in.php");
                exit; // Stop further execution
            } else {
                $_SESSION["err3"] = "Invalid code! Please try again.";
            }
        }
    }
    curl_close($ch);
?>
