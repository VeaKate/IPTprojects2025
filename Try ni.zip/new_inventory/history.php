
<?php
    include("header.php");
?>

<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>History</title>
    <link rel="icon" type="image/png" href="newLogo.png">
    </head>
    <body>
    <div id="trans">Transactions History
    </div>
    <hr>
        <div id="records">
            <div class="rec">
            09/27/2018
            <div class="button"><button class="but">Delete</button></div>
            <hr>
        </div>
        <div class="rec">
            09/27/2018
            <div class="button"><button class="but">Delete</button></div>
            <hr>
        </div>
        <div class="rec">
            09/27/2018
            <div class="button"><button class="but">Delete</button></div>
            <hr>
        </div>
            <div class="rec">
            09/27/2018
            <div class="button"><button class="but">Delete</button></div>
            <hr>
        </div>
            <div class="rec">
            09/27/2018
            <div class="button"><button class="but">Delete</button></div>
            <hr>
        </div>
        <div class="rec">
            09/27/2018
            <div class="button"><button class="but">Delete</button></div>
            <hr>
        </div>
        <div class="rec">
            09/27/2018
            <div class="button"><button class="but">Delete</button></div>
            <hr>
        </div>
        <div class="rec">
            09/27/2018
            <div class="button"><button class="but">Delete</button></div>
            <hr>
        </div>
        <div class="rec">
            09/27/2018
            <div class="button"><button class="but">Delete</button></div>
            <hr>
        </div>
    </div>
    </body>
</html>

<style>
    body {
        margin: 0;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #f4f6f8;
        color: #333;
    }

    #trans {
        margin-top: 0;
        font-size: 32px;
        font-weight: bold;
        background-color: #2c3e50;
        color: #ffffff;
        padding: 25px;
        text-align: center;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }

    .rec {
        margin: 20px auto;
        padding: 20px;
        font-size: 20px;
        background-color: #ffffff;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        max-width: 700px;
        color: #2c3e50;
        position: relative;
    }

    .button {
        position: absolute;
        top: 50%;
        right: 20px;
        transform: translateY(-50%);
    }

    .but {
        width: 120px;
        height: 40px;
        font-weight: bold;
        background-color: #e74c3c;
        color: #fff;
        border: none;
        border-radius: 25px;
        cursor: pointer;
        transition: background-color 0.3s ease, transform 0.2s ease;
    }

    .but:hover {
        background-color: #c0392b;
        transform: scale(1.05);
    }

    hr {
        border: none;
        border-top: 1px solid #ddd;
        margin: 10px 0;
    }
</style>
